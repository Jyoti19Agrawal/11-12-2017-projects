/**************************************************************
File Name   : ShowController.java
Author      : Vinayak Kanase.
Description : Consist of Logic 
 ***************************************************************/
package com.cg.ogp.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.ogp.bean.GameDetails;
import com.cg.ogp.exception.GamingException;
import com.cg.ogp.service.GameServiceImpl;
import com.cg.ogp.service.IGameService;

/*******************************************************************************************************
- Class Name		:	GameController 
- Author			:	Jyoti Agrawal
- Creation Date	    :	11/12/2017
- Description		:	Controller(Servlet)
********************************************************************************************************/

@WebServlet(urlPatterns = { "/listAllGames", "/getGameDetails", "/BookGame" })
public class GameController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	IGameService gameService;

	public GameController() {
		super();
		gameService = new GameServiceImpl();

	}

	public void init(ServletConfig config) throws ServletException {

	}

	public void destroy() {

	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// calling doPost in doGet
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		String path = request.getServletPath();
		System.out.println("path=" + path);
		String url = "";

		try {
			switch (path) {
			// firstcase which will show all details
			case "/listAllGames":
				System.out.println("Hello");
				List<GameDetails> showList = gameService.getGameDetails();
				// System.out.println(showList);
				HttpSession session = request.getSession();
				session.setAttribute("showList", showList);
				url = "GameDetails.jsp";
				break;

			// second case which will send us to show bookNow.jsp
			case "/getGameDetails":
				System.out.println("Getting Game Details");
				String gameid = request.getParameter("gameid");
				System.out.println(gameid);
				GameDetails show = gameService.getGameDetail(gameid);
				System.out.println(show);
				request.setAttribute("show", show);
				url = "bookNow.jsp";
				break;

			/*
			 * third case which will book ticket based on the values enterd in
			 * bookNow.jsp and redirect to success.jsp if booking is done
			 * successfully
			 */
			case "/BookGame":
				String gameName = request.getParameter("txtShowName");
				double price = Double.parseDouble(request
						.getParameter("txtPrice"));
				String customerName = request.getParameter("txtCustName");
				long mob = Long.parseLong(request.getParameter("txtMobNo"));
				int availGame = Integer.parseInt(request
						.getParameter("txtSeatsAvail"));
				int noOfSeats = Integer.parseInt(request
						.getParameter("txtSeatsBook"));

				if (noOfSeats == 0 || noOfSeats < 0) {
					throw new GamingException("Please Enter valid no of games");
				}

				if (availGame < noOfSeats) {
					throw new GamingException("Please Enter valid no of games");
				} else {
					int updatedSeats = availGame - noOfSeats;
					request.setAttribute("gamename", gameName);
					request.setAttribute("cname", customerName);
					request.setAttribute("mobileNo", mob);
					request.setAttribute("noOfSeats", noOfSeats);
					double totalPrice = price * noOfSeats;
					request.setAttribute("totalPrice", totalPrice);
					gameService.updateGameDetails(updatedSeats, gameName);
					url = "success.jsp";
				}

				break;

			default:
				break;
			}
		} catch (GamingException e) {
			request.setAttribute("error", e.getMessage());
			url = "error.jsp";
		} catch (Exception e) {
			request.setAttribute("error", e.getMessage());
			url = "error.jsp";
		}

		RequestDispatcher rd = request.getRequestDispatcher(url);
		rd.forward(request, response);
	}

}
