package com.cg.ogp.dao;

import java.util.List;

import com.cg.ogp.bean.GameDetails;
import com.cg.ogp.exception.GamingException;

/*******************************************************************************************************
- Interface Name	:	IGameDAO
- Throws			:  	GamingException
- Author			:	Jyoti Agrawal
- Creation Date		:	11/12/2017
- Description		:	Dao Interface
********************************************************************************************************/

public interface IGameDAO 
{
	List<GameDetails> getGameDetails() throws GamingException ;
	public GameDetails getGameDetail(String showid) throws GamingException ;
	public void updateGameDetails(int games , String gamename) throws GamingException ;
}
