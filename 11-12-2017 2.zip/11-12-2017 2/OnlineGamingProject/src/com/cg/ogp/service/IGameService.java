package com.cg.ogp.service;

import java.util.List;

import com.cg.ogp.bean.GameDetails;
import com.cg.ogp.exception.GamingException;


/*******************************************************************************************************
- Interface Name	:	IGameService
- Throws			:  	GamingException
- Author			:	Jyoti Agrawal
- Creation Date		:	11/12/2017
- Description		:	Service Interface
********************************************************************************************************/

public interface IGameService 
{
	List<GameDetails> getGameDetails() throws GamingException ;
	public GameDetails getGameDetail(String showid) throws GamingException ;
	public void updateGameDetails(int games , String gamename) throws GamingException ;
}
