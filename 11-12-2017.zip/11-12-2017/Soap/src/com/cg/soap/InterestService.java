package com.cg.soap;

import javax.jws.WebMethod;
import javax.jws.WebService;

@WebService

public interface InterestService {
@WebMethod
public double compoundInterest(double principal, 
double rate, double time);

@WebMethod
public double simpleIntrest(double principal, 
double rate, double time);
}