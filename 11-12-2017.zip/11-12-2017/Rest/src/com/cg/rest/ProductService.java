package com.cg.rest;

import javax.ws.rs.FormParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.Response;
@Path("/product")  
public class ProductService {
@POST
@Path("/add")
public Response addUser(@FormParam("pname") String product, 
@FormParam("pquan") float quan, 
@FormParam("pprice") float price) 
{
return Response.status(200)
.entity(" Final Bill is !<br> Product Name : " +
product + "<br> Quantity: " + quan + "<br> Price: " + 
price+"<br> Amount "+price*quan)
.build();
}
}